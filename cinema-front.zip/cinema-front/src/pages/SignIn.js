import React from 'react';
import Wrapper from '../components/Wrapper';
import SignInComp from '../components/SignInComp';

function SignIn() {
    return (
        <Wrapper>
            <SignInComp/>
        </Wrapper>
    );
}

export default SignIn;