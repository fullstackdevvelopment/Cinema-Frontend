import React from 'react';
import Wrapper from '../components/Wrapper';

function SignUp() {
    return (
        <Wrapper>

        </Wrapper>
    );
}

export default SignUp;