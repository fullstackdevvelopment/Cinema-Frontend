import React from 'react';
import Wrapper from '../components/Wrapper';

function Contact() {
    return (
        <Wrapper>

        </Wrapper>
    );
}

export default Contact;