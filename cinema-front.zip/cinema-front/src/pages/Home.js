import React from 'react';
import Wrapper from '../components/Wrapper';

function Home() {
    return (
        <Wrapper>

        </Wrapper>
    );
}

export default Home;