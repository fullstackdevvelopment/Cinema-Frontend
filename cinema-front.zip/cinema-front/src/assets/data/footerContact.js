import locationImg from '../images/location.png';
import phoneImg from '../images/phone.png';
import emailImg from '../images/email.png';

const footerContact = [
    {
        id: 1,
        image: locationImg,
        link: 'https://www.google.com/maps/place/Gayi+Street,+Gyumri/@40.7859427,43.837268,17z/data=!3m1!4b1!4m6!3m5!1s0x4041fb8bf5996985:0x540f2a43cfac6a43!8m2!3d40.7859427!4d43.8398429!16s%2Fg%2F1v7pwzbj?entry=ttu',
        title: 'Armenia Gyumri Gayi1 Street'
    },
    {
        id: 2,
        image: phoneImg,
        link: 'tel:+37494558806',
        title: '+37494558806'
    },
    {
        id: 3,
        image: emailImg,
        link: 'mailto:Fmovie.cineam@gmail.com',
        title: 'Fmovie.cineam@gmail.com'
    }
];

export default footerContact;