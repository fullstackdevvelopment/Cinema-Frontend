import facebook from '../images/footer-fb.png';
import instagram from '../images/footer-insta.png';
import twitter from '../images/footer-twit.png';
import google from '../images/footer-google.png';

const footerIconData = [
    {id: 1, image: facebook, url: 'https://www.facebook.com/'},
    {id: 2, image: instagram, url: 'https://www.instagram.com/'},
    {id: 3, image: twitter, url: 'https://twitter.com/?lang=en'},
    {id: 4, image: google, url: 'https://www.google.com/'}
];

export default footerIconData;