import React from 'react';
import '../assets/styles/_navbar.scss';
import logo from '../assets/images/logo.png';
import {Link} from 'react-router-dom';

function App() {
    return (
        <div className='container'>
            <nav className='nav'>
                <div className='logo'>
                    <Link to='/home'>
                        <img className='logo__img' src={logo} alt="Logo"/>
                    </Link>
                </div>
                <ul className='nav__block'>
                    <li className='nav__list'><Link className='nav__link__active' to='/home'>Home</Link></li>
                    <li className='nav__list'><Link className='nav__link__active' to='/catalog'>Catalog</Link></li>
                    <li className='nav__list'><Link className='nav__link__active' to='/contact'>Contact Us</Link></li>
                </ul>
                <ul className='sign__block'>
                    <li className='sign__list'><Link className='sign__link__active' to='/signIn'><button className='signin__btn'>Sign In</button></Link></li>
                    <li className='sign__list'><Link className='sign__link__active' to='/signUp'><button className='signup__btn'>Sign Up</button></Link></li>
                </ul>
            </nav>
        </div>
    );
}

export default App;
