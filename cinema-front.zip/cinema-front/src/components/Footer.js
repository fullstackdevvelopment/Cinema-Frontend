import React from 'react';
import '../assets/styles/_footer.scss';
import logo from '../assets/images/logo.png';
import {Link} from 'react-router-dom';
import clogo from '../assets/images/clogo.png';
import footerIconData from '../assets/data/footerIconData';
import footerContact from '../assets/data/footerContact';
import appStore from '../assets/images/app-store.png';
import playStore from '../assets/images/play-store.png';

function Footer() {


    return (
        <footer className="footer">
            <div className='container'>
                <div className='footer__box'>
                    <div className='footer__logo__div'>
                        <img className='footer__logo' src={logo} alt="logo"/>
                    </div>

                    <div className='footer__line'></div>


                    <ul className='about__block'>
                        <li className='about__list'><Link to='/about' className='about__link__active'><h2
                            className='footer__block__title'>About</h2></Link></li>
                        <li className='about__list'><Link to='/home' className='about__link__active'>Home</Link></li>
                        <li className='about__list'><Link to='/catalog' className='about__link__active'>Catalog</Link>
                        </li>
                        <li className='about__list'><Link to='/profile' className='about__link__active'>Profile</Link>
                        </li>
                    </ul>

                    <ul className='menu__block'>
                        <li className='menu__list'><Link to='/menu' className='menu__link__active'><h2
                            className='footer__block__title'>Menu</h2></Link></li>
                        <li className='menu__list'><Link to='/latest' className='menu__link__active'>Latest</Link></li>
                        <li className='menu__list'><Link to='/comingsoon' className='menu__link__active'>Coming
                            Soon</Link></li>
                        <li className='menu__list'><Link to='/featured' className='menu__link__active'>Featured
                            movies</Link></li>
                    </ul>
                    <ul className='contact__block'>
                        <h2 className='contact__block__title'>Contact Us</h2> <br/>
                        {footerContact.map(contact => (
                            <li key={contact.id} className='contact__list'>
                                <div className='contact__item'>
                                    <img className='footer__contact__img' src={contact.image} alt={contact.title}/>
                                    <Link className='contact__link__active' to={contact.link}>{contact.title}</Link>
                                </div>
                            </li>
                        ))}
                    </ul>

                </div>

                <ul className='additional__block'>
                    <li className='additional__list'>
                        <Link className='additional__title' to='/'>
                            Copyright
                        </Link>
                        <img className='additional__title' src={clogo} alt=""/>
                        <Link className='additional__title' to='/'>
                            2023Fmovie. Cinema
                        </Link>
                    </li>
                    <li className='additional__list'>
                        <div className='follow'>
                            <h2 className='follow__title'>Follow Us</h2>
                            <div className='footer__softwares'>
                                {footerIconData.map(icon => (
                                    <div key={icon.id} className='footer__software'>
                                        <Link to={icon.url}>
                                            <img className='footer__software__img' src={icon.image} alt="icon"/>
                                        </Link>
                                    </div>
                                ))}
                            </div>
                        </div>
                    </li>
                    <li className='additional__list'>
                        <div className='app__stores'>
                            <Link to='https://play.google.com/store/games?hl=en&gl=US&pli=1'><img className='app__stores__img' src={playStore} alt="Google Play"/></Link>
                            <Link to='https://www.apple.com/app-store/'><img className='app__stores__img' src={appStore} alt="App Store"/></Link>
                        </div>
                    </li>

                </ul>

            </div>
        </footer>
    );
}

export default Footer;
