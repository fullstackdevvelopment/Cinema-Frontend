import React from 'react';
import NavBar from './NavBar';
import Footer from './Footer';

function Wrapper(props) {
    return (
        <div className='wrapper'>
            <NavBar/>
            {props.children}
            <Footer/>
        </div>
    );
}

export default Wrapper;