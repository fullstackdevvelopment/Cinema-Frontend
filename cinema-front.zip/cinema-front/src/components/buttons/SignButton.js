import React from 'react';
import '../../assets/styles/_signBtn.scss';

function SignButton(props) {
    return (
        <div className={props.className}>
            <div className='sign__btn__div'>
                <button className='sign__btn'>{props.text}</button>
            </div>
        </div>
    );
}

export default SignButton;